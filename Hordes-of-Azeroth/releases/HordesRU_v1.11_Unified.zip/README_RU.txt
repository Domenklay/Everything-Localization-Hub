HordesRU 1.11 — единый русский аддон для Hordes of Azeroth 0.6.x

1. Закройте игру и лаунчер.
2. Удалите из папки игры старые папки benilla-config\AddOns\HordesRU и HordesRU_Expansion.
3. Распакуйте содержимое этого ZIP в корень игры рядом с WoW.exe.
4. Запустите игру. Останется одна папка AddOns\HordesRU.

Шрифт Noto Sans KR включается по умолчанию при первом запуске v1.11.
Команды: /hru font kr, /hru font sc, /hru, /hruexp. После смены шрифта /reload.

Исходники и инструкция:
https://github.com/Domenklay/Everything-Localization-Hub/tree/main/Hordes-of-Azeroth

Не меняет WoW.exe и игровые MPQ. Server-side перевод ещё может быть частичным.
